MJ ARTS WEBSITE

Open index.html in a browser to preview the site.

The site is a static HTML/CSS page and is ready to deploy on GitHub Pages.
WhatsApp and email buttons are already connected to the contact details supplied for MJ Arts.
